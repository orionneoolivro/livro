# NADA DE OI, SUMIDA
## O guia sem vergonha pra quem quer flertar sem ser mais do mesmo.

## INTRODUÇÃO

CHINELO E CALÇA JEANS NÃO É ESTILO.
SHOPPING NÃO É LUGAR DE ENCONTRO.
CAMISA DE TIME NO ENCONTRO NÃO, POR FAVOR.
FOI AQUI QUE PEDIRAM UMA PIZZA?
CINEMA NO PRIMEIRO ENCONTRO? NÃO!

Essas são algumas frases que você vai ler durante esse e-book, mas não fica triste não que é pior, vai por mim, elas e eles que me contaram.

Me chamo Wellington Coelho, tenho 24 anos e canso de ler comentários desnecessários de pessoas tentando chamar atenção umas das outras. E naquele momento infeliz perder qualquer oportunidade que poderia ter, acredito que todo mundo tem a oportunidade de ter um encontro com a pessoa dos sonhos, você só precisa criar as oportunidades corretas na hora de iniciar uma conversa.

NÃO, por favor, não chama ela de gostosa na foto.
E NÃO, não pergunta se ela se machucou quando caiu do céu porque ela é um anjo.

E pra vocês, mulheres, NÃO, não precisa esperar ele dar o primeiro passo.
E NÃO, não manda aquele "oi sumido" achando que vai reconquistar alguém.

Não pode fazer isso, ok?
Oii,
Tudo bem?
Novidades?
Você é de onde?
Fazendo o que?

VAMOS CRIAR OPORTUNIDADE.

Como está sendo sua semana?
Conhece aquele lugar...?
O que achou quando foi lá?
Trabalha com o que gosta, ou pensa em fazer outra coisa?

Seja sincero, acha mesmo que invadindo a vida de alguém em 5 minutos você vai ter sua atenção? Ok, não estou aqui para apontar de cara o que você não deve fazer, mas por favor não seja desagradável e por isso vamos começar falando um pouco de como podemos iniciar uma conversa, o que acha? 

Essa sem dúvida é um dos maiores problemas, concorda comigo? As pessoas estão ganhando a autoridade que querem, não estão erradas em conquistar isso, só que criou uma análise mais rígida em relação a quem vai ter sua atenção e nesse caso precisamos mudar nossa forma de conversa, desde do "oi" à roupa que vamos usar, o lugar que vamos levar, e de que forma vamos terminar o dia, mas tenho certeza que isso fez com que ficasse muito mais interessante, saber o que fazer nessas horas e se destacar entre tantos outros.

Querendo ou não isso é um jogo, a vida é um jogo em todos os aspectos e existem aqueles que se destacam, concorda comigo? Pensa bem, no Brasil existem 209,5 milhões de pessoas, sendo 100,5 milhões de mulheres e 109 milhões de homens.

Teoricamente a pessoa que você sonha tem milhões de concorrentes.

Eu afirmo que o primeiro passo e um dos mais importantes nesse momento é pensar: o que todos fariam? Pode parecer uma pergunta bem simples e bem clichê concorda? Mas eu afirmo que essa pergunta realmente faz diferença.

Neste e-book expandido, vamos explorar não apenas como os homens podem se destacar ao flertar com mulheres, mas também como as mulheres podem tomar a iniciativa e criar conexões genuínas. Porque, no final das contas, todos queremos a mesma coisa: criar momentos especiais com pessoas que nos interessam, sem cair nas mesmas armadilhas de sempre.

Então prepare-se para um guia completo, direto e sem filtros sobre como se destacar no jogo da conquista - seja você homem ou mulher. Vamos lá?
