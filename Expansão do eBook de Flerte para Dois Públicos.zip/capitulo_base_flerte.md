# A BASE DO FLERTE

Desliga nesse momento o que você está fazendo além de estar lendo, você vai imaginar duas cenas comigo, a primeira talvez não seja tão real quanto a segunda, vamos lá.

Primeira cena acontece principalmente em escolas/faculdades. A pessoa está usando um vestido ou saia o que é bem comum e com ela uma mochila ou uma bolsa, em algumas vezes esse objeto acaba prendendo na roupa fazendo com que sua roupa suba, tenho certeza que nesse momento a probabilidade de alguém chamar sua atenção para o que está acontecendo é MUITO baixa, e na maioria das vezes uma outra pessoa vai fazer esse comentário, agora imagina se você, naquele momento parar ao lado dela e fazer algum comentário descontraído avisando da situação, lembrando que por ser uma situação delicada, cuidado para não sair de descontraído para assédio, mesmo que esteja avisando sobre uma situação constrangedora. 

Você fez um comentário, ela riu de vergonha e logo em seguida continuou a conversa "– É por isso que não venho de mochila, ou talvez seja porque não gosto de estudar." Qualquer coisa que faça ela te dar uma atenção maior, trazendo para vocês uma oportunidade de se falar mais vezes.

Viu como agir diferente da maioria pode te trazer uma chance maior com a pessoa que você gosta, ou tem desejo? Sei que essa cena não é tão comum, mas tenho certeza que você entendeu o que eu quis dizer! Agora vamos criar uma outra cena onde vamos não só entender melhor isso que eu quero falar, mas você vai poder nesse momento coloca em prática com ela. Ela, no caso, é a pessoa que você quer ter 5 minutos de sua atenção.

Assim que terminar esse capítulo você pode correr na rede social dela e usar a ideia a seu favor.

Bom, como eu disse essa cena vai ser mais realista. Digamos que você está olhando algumas fotos que postaram nas redes sociais e de repente você vê a foto de uma determinada pessoa e é aquela pessoa, aquela que se você pudesse ficaria horas conversando, imagina comigo então para você entender o que você tem que fazer. 

Ela está na praia, de biquíni talvez com um suco ou uma cerveja na mão e te dou certeza que 90% dos comentários seria dos homens falando sobre a beleza, o corpo, até sobre o biquíni TENTANDO parecer "diferente" e 9% as amigas falando o quanto ela é linda correto? E a probabilidade dessa pessoa responder ao seu comentário é baixa levando em consideração que TODOS, TODOS, estariam pensando a mesma coisa na hora de comentar ou fazer um elogio e com isso te afirmo que por mais que receber um elogio faz bem ela sabe exatamente que ela é bonita, que chama atenção e você não vai conseguir ter a atenção dela sendo mais um comentando "fica difícil saber quem é mais bonito, esse céu, o mar ou você".

Foca exatamente no que eu tenho para te falar agora.
É nessa hora que você vai se destacar!
Primeiro passo é OBSERVAR, anota ai, OBSERVAR!
Repete comigo, mais uma vez, só para você não esquecer;
O primeiro passo é? OBSERVAR!

Lembrando que a observação vai variar de foto para foto, mas nessa cena você vai observar a foto dela na praia com os seguintes pontos chaves:

- Primeiro: qual é a praia que ela está? É conhecida? É próxima? Ela marcou esse lugar? Você ou seus amigos costumam ir?
- Segundo: ela está em algum quiosque? Se estiver, qual o nome? Você já foi? Conhece alguém que foi? Procura o Instagram desse quiosque e veja os tipos de bebidas, comidas e pessoas que frequentam.
- Terceiro: no dia que ela foi teve algum show ao vivo? Alguma atração, caso tenha a probabilidade de ela ter ido devido aquela atração é alta então ela provavelmente gosta daquele ritmo e ambiente.
- Quarto: comida ou bebida em cima da mesa? Observe se ela está bebendo, observe o que ela está comendo, se é doce, salgado, se é uma bebida alcoólica ou suco.
- Quinto: ela postou alguma música no story? Talvez cantando, talvez ela colocou, isso é um ponto importante para você descobrir um pedaço do gosto musical dela.

Como eu disse seu objetivo é simplesmente observar. Seus elogios não podem ser iguais aos outros 99% dos homens que são: linda, gostosa, delicia, ou algo como eu li uma vez que era "Não cabe em um comentário, todas as qualidades que vc tem, sou seu fã de carteirinha pq vc é uma MULHER LINDA". Você precisa ser o 1% que eu deixei em aberto na página anterior.

Ok, ok, ok.

Nesse momento vou levar você para uma leitura mais interessante e agora eu vou criar a oportunidade de iniciar uma conversa se baseando nos pontos que observamos, vamos gerar a dúvida antes mesmo dela abrir sua conversa, sério, ela nem abriu a sua conversa e você vai deixá-la com a dúvida, sim, é exatamente isso que você está lendo.

Sabe quando você recebe uma mensagem e aparece parte dela antes de você abrir? Quando chega a notificação que arrastamos pra baixo para poder ler mais sem visualizar, ou quando entramos no privado e vimos as mensagens que recebemos e podemos ler um pedaço pequeno? É exatamente nessas poucas palavras que você vai gerar curiosidade nela, que você vai deixar o desejo, a curiosidade dela para poder clicar em sua conversa e abrir.

Temos 5 palavras na notificação, e você vai usar isso a seu favor!

Vamos mudar as frases héterotop, aquelas que eu citei ali em cima que 90% dos homens usam, vamos mudar para algo que realmente seja diferente e que ela tenha essa atenção que você precisa. Você observou lugar, comida, bebida, gosto musical e alguns outros detalhes pela foto e marcações.

Depois de observar você vai criar um comentário, esse comentário precisa começar com algo que vou chamar de campainha, porque por mais que a pessoa não esteja te vendo de alguma forma você chama atenção dela.

"- Oi, tudo bem com você?

x - Preciso muito da sua ajuda!"

Qual das duas você iria abrir primeiro?

É isso que eu quero que faça, quero que logo no começo você crie essa campainha/desejo dela responder você.

"Preciso muito da sua ajuda, eu vi que postou uma foto no quiosque X e tenho muita vontade de ir lá, porém, nunca tive a oportunidade, pode me dizer se você gostou? Em relação a comida, as bebidas, atendimento... sem querer ser invasivo, por favor".

Lembra o que eu falei sobre usar as poucas palavras da notificação mesmo ela não abrindo sua mensagem para chamar atenção, você acaba de fazer isso quando usou "Preciso muito da sua ajuda..." e logo em seguida sua pergunta.

Qual mulher ou até mesmo homem que não iria abrir a conversa quando você começa a frase criando a curiosidade e tornando a opinião dela importante.

Vou tentar dar mais um exemplo para poder te dar mais uma carta nesse jogo, você pode criar uma história para chamar atenção? Depois de observar tudo, lógico. Você pode comentar algo como:

"- Juro que fiquei triste com esse quiosque, sua porção de batata frita está muito maior do que a minha, tem alguma coisa errada!"

Seguido de alguma coisa para criar um ar de brincadeira.

Olha como você iniciou a mensagem "Juro que fiquei triste com esse" estamos usando a campainha de novo, criando a curiosidade para que ela abra sua conversa. Você entendeu? Saímos da realidade masculina de primeiro elogiar de forma evasiva e entramos com um comentário onde vai gerar curiosidade e uma resposta com uma possível pergunta, como assim? Não desgruda de mim, continua lendo que tudo que eu falar eu vou te explicar ok?

Lembra da pergunta que você fez sobre o quiosque? Sobre o atendimento, comida, bebidas e local? Isso pode seguir de uma resposta onde ela vai lhe dar a oportunidade de continuar essa conversa, é lógico que podem ter diversas respostas, mas qualquer resposta dela vai deixar você livre para continuar o assunto. Digamos que ela resposta dessa forma:

"Eu gostei demais, na verdade não é a primeira vez que eu vou, gosto muito do ambiente e da comida, mas porque falta de oportunidade?"

Ela criou a oportunidade de você mandar mais uma mensagem, e nessa hora você precisa mostrar que você tem valor, pode falar sobre algum projeto, sobre o trabalho, sobre coisas que você faz que te deixam sem tempo, talvez sobre o foco que você tem no seu futuro, lembrando que por mais que você fale que a culpa é porque você tem foco no seu trabalho você não vai deixar que isso se torne um problema para ela pensar "ele trabalha demais." Porque querendo ou não ela pode não te dar atenção por achar que você nunca vai poder dar atenção para ela, mesmo que seja o início de uma conversa isso pode acontecer.

E se ela responder fazendo com que você não tenha uma oportunidade de continuar essa conversa? Sem uma pergunta vindo dela como a primeira resposta? Ela pode simplesmente responder todas as suas perguntas e apenas nisso, mas podemos sair dessa sinuca, vamos iniciar uma conversa indireta, como eu gosto de exemplo, vamos para mais um:

"- eu gostei muito, a comida, as bebidas, os atendentes são super gente boa e o clima nem se fala."

Percebeu que ela não te fez uma pergunta criando a possibilidade de você continuar o assunto, certo? Então você primeiro vai agradecer, obvio! E logo em seguida você pode continuar dessa forma:

"Sério? eu preciso ir e tirar essa coisa de ficar na vontade! Correria de projetos, sair um pouco para conversar, ouvir uma música desligar um pouco a cabeça seria bom, muito obrigado pela resposta! Ah, última pergunta, fica onde esse quiosque?"

Esse foi o primeiro contato com ela então não espere que ela vai lhe dar o número dela, ou que você vai passar a madrugada conversando com ela, lógico, se conseguir criar uma conversa longa e interessante meus parabéns, mas estamos falando sobre probabilidades! Por mais que breve, interessante e o principal, que ela te responda.

Então vamos aos pontos principais que você leu até agora, o mais importante é que você não pode fazer parte dos 90%, você precisa observar, enviar uma mensagem criando nossa campainha, e ir criando oportunidade para que você possa continuar conversando, e lembre-se de nunca criar um personagem, seja você porque a pior coisa do mundo é ela perceber que você não está sendo o mesmo durante suas conversas ou encontros.

Continuo afirmando, não esqueça, NUNCA, NUNCA, NUNCA. Que suas respostas devem conter a oportunidade de deixá-la fazer uma nova pergunta, você sempre vai conversar tentando deixando uma pergunta aberta para que ela possa responder e você consiga responder e assim sucessivamente.

Percebeu como não é difícil você ter contato com a pessoa que lhe chama atenção? Ninguém está vendo que você tem medo, vergonha, se você é tímido, estamos falando de mídias sociais, você precisa saber se posicionar. Porém sabe qual é o maior problema do contato por mídia social ou até mesmo pessoalmente? É que todos nós temos um pré-julgamento e isso acaba criando uma barreira para as pessoas que tem aquele encaixe que precisamos, que vai nos trazer momentos engraçados e únicos. E isso acaba fazendo com que a gente viva por aparências, perdendo momentos incríveis que poderíamos ter com outras pessoas que realmente nos faria feliz e traria momentos marcantes seja com algo sério ou não.

Eu acredito que todos nós temos a chance de ter aquela pessoa que sempre sonhamos, talvez essa pessoa é quem você acredita ser que te faria feliz mesmo que seja por uma amizade, sendo que para isso pode acontecer você vai ter que fazer acontecer.

Criando a oportunidades para que ela possa ver você, possa reparar você por algum motivo que você vai criar, seja com uma mensagem pedindo ajuda ou um comentário engraçado na festa com os amigos.

Agora que você já tem uma base sobre como iniciar uma conversa, vamos falar do próximo passo que só depende de você!

Calma, calma, calma, deixa eu dar mais uma dica e essa eu tenho certeza que você vai achar que estou de brincadeira, mas vai por mim, funciona com 90% das mulheres e se não funcionar você vai fazer ela dar uma risada e isso já é um belo passo, e vamos combinar irmão que no século XXI, qual a mulher que não gosta de comer?

Digamos que você consiga o número dela e vai deixar uma mensagem, lembra o princípio de tudo? o que todos fariam? E nessa hora eles vão começar com "oi, está salvo. Demorei pra chamar? Agora sim dá pra conversar direito! Onde a gente parou?" se você sabe que isso é o normal, que é isso que 99% dos homens fariam você não vai repetir esse erro né? Presta atenção nessa dica:

## FOI AQUI QUE PEDIRAM UMA PIZZA?

"Boa tarde X, tudo bom? Aqui é da Pizzaria: Sonhei com Pizza e depois do nosso SORTEIO você acaba de ganhar um VOUCHER para um RODÍZIO de Pizza, para confirmar e receber mais informações por favor digite a opção desejada:
1 – Próximo fim de semana.
2 – Irei marcar uma data.
3 – Não quero esse voucher.

Você acaba de iniciar a uma conversa completamente extrovertida, ela com certeza vai estar rindo e nesse momento ela provavelmente vai até o seu perfil, olhar suas fotos, pensar um pouco sobre o seu pedido, mas fica tranquilo que ela vai estar rindo, e nesse momento o que vale é se destacar de qualquer possível concorrente, certo?

Depois da resposta dela é claro que você vai continuar de forma descontraída e por favor, esqueça um novo convite para sair, ou não faça elogios sobre ela! Por mais que mulheres gostem de elogios você não vai ser mais um que vai ficar elogiando a cada 5 minutos, então, por esse motivo sua conversa vai ser completamente aleatória, trazendo um conforto para ela, criando aquela frase maravilhosa "parece que a gente se conhece a anos" ai sim você vai estar no caminho certo, porque por mais que tenha pouco tempo de conversa você ja vai ter criado um pouco de intimidade com ela deixando ela completamente a vontade para a conversa fluir de formar leve, sem você ter que forçar uma resposta ou continuar com perguntar idiotas.

Não estou dizendo que isso é uma obrigação, não me entenda errado! Cada um lógico tem um jeito diferente de abordar as coisas, seja com um convite, uma piada, uma brincadeira, eu só quis mostrar uma forma descontraída para você iniciar a conversar com ela! E vamos ser realistas, quem em sã consciência ia mandar uma mensagem falando que ela ganhou um voucher de rodízio de pizza? E é por isso que você vai fazer isso, ou, algo na mesma direção, porque você vai ser, o que? DIFERENTE.

Não pode ser mais um, NÃO PODE SER MAIS UM.

## CHINELO E CALÇA JEANS NÃO É ESTILO.

Ficou triste foi? Mas não, não fica triste não, é a realidade! Não vou fazer essa comparação usando mulher, vou falar de homem mesmo! E vou usar uma comparação que eu tenho certeza que você vai entender, pega a visão! Imagina você estar dentro de uma Ferrari, um Porsche ou que tal um Aston Martin e a roda for de FERRO, irmão, vamos ser sinceros comigo com você e com elas, vai estar horrível.

Então nesse tópico eu vou falar um pouco de alguns estilos que você pode usar e não só usar, você vai entender onde e quando e até mesmo com quem usar, não desiste agora não, você já chegou na parte onde ela aceitou seu pedido para ir ao encontro então agora você precisa manter-se focado! Segue a gestão que no final vai dar certo.

Ah, só mais uma coisa.

## CAMISA DE TIME NO ENCONTRO NÃO, POR FAVOR.

Não fui eu que disse isso, foram elas e isso não é uma brincadeira!

## SHOPPING NÃO É LUGAR DE ENCONTRO

Amiguinho, vamos parar de pensar em shopping na primeira oportunidade que você tiver. Existem diversos lugares até mesmo gratuitos que você pode ir no primeiro encontro, e isso você vai descobrir durante a conversa que estiver com aquela menina que você observou e observou. E agora você esta aqui, conversa ok, estilo ok, não vai querer errar no lugar correto?

Sabe o que você vai ter que fazer depois de chegar nesse ponto da historia? Adivinha? OBSERVAR, você vai observa o que ela gosta de fazer, conversa com ela como são os dias dela, como são os finais de semanas! Será que ela gosta de barulho ou algo mais silencioso, sera que ela prefere dia ou noite, um suco, refrigerante ou cerveja? Todo o gosto dela vai fazer você mudar o local do primeiro encontro então você vai ter que continuar fazendo seu dever de casa.

Digamos que nas fotos dela contém mu
(Content truncated due to size limit. Use line ranges to read in chunks)